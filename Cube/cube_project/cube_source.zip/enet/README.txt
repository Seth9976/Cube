Please visit the ENet homepage at http://enet.bespin.org for installation
and usage instructions.

If you obtained this package from CVS, the quick description on how to build
is:

# Generate the build system.

aclocal && automake -a -c --foreign && autoconf

# Compile and install the library.

./configure && make && make install

See pyenet/readme.txt for further information on Ling Lo's Python wrapper for
ENet.
